// crates/shaders/src/init_sparse_push_sources_512.wgsl
// Multi-Word Source Initialization for 512 sources (16 words)

struct InitSourcesParams {
    num_vertices: u32,
    num_sources: u32,
    chunk_start: u32,
    pad0: u32,
};

@group(0) @binding(0) var<uniform> params: InitSourcesParams;
@group(0) @binding(1) var<storage, read> sources: array<u32>;
@group(0) @binding(2) var<storage, read_write> frontiers: array<atomic<u32>>;
@group(0) @binding(3) var<storage, read_write> visited: array<atomic<u32>>;

@group(0) @binding(4)  var<storage, read_write> dist_bank0: array<u32>;
@group(0) @binding(5)  var<storage, read_write> dist_bank1: array<u32>;
@group(0) @binding(6)  var<storage, read_write> dist_bank2: array<u32>;
@group(0) @binding(7)  var<storage, read_write> dist_bank3: array<u32>;
@group(0) @binding(8)  var<storage, read_write> dist_bank4: array<u32>;
@group(0) @binding(9)  var<storage, read_write> dist_bank5: array<u32>;
@group(0) @binding(10) var<storage, read_write> dist_bank6: array<u32>;
@group(0) @binding(11) var<storage, read_write> dist_bank7: array<u32>;

const MAX_WORDS: u32 = 16u;

@compute @workgroup_size(256)
fn main(
    @builtin(workgroup_id) group_id: vec3<u32>,
    @builtin(local_invocation_id) local_id: vec3<u32>,
    @builtin(num_workgroups) num_workgroups: vec3<u32>
) {
    let total_threads = num_workgroups.x * 256u;
    for (var s = group_id.x * 256u + local_id.x; s < params.num_sources; s = s + total_threads) {
        let src = sources[s];
        let nv = params.num_vertices;
        if (src >= nv) {
            continue;
        }

        let word_idx = s / 32u;
        let bit_idx = s % 32u;
        let mask = 1u << bit_idx;

        let v_base = src * MAX_WORDS;
        atomicOr(&frontiers[v_base + word_idx], mask);
        atomicOr(&visited[v_base + word_idx], mask);

        let b_shift = select(6u, params.pad0 & 0xFFu, (params.pad0 & 0x100u) != 0u || params.pad0 > 0u);
        let b_mask = (1u << b_shift) - 1u;
        let bank = s >> b_shift;
        let local_s = s & b_mask;
        let dist_idx = local_s * nv + src;

        switch (bank) {
            case 0u: { dist_bank0[dist_idx] = 0u; }
            case 1u: { dist_bank1[dist_idx] = 0u; }
            case 2u: { dist_bank2[dist_idx] = 0u; }
            case 3u: { dist_bank3[dist_idx] = 0u; }
            case 4u: { dist_bank4[dist_idx] = 0u; }
            case 5u: { dist_bank5[dist_idx] = 0u; }
            case 6u: { dist_bank6[dist_idx] = 0u; }
            case 7u: { dist_bank7[dist_idx] = 0u; }
            default: {}
        }
    }
}
